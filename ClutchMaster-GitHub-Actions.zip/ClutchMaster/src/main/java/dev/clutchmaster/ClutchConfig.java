package dev.clutchmaster;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public final class ClutchConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("clutchmaster.json");
    public static Settings CONFIG = new Settings();

    private ClutchConfig() {}

    public static void load() {
        if (!Files.exists(FILE)) {
            save();
            return;
        }
        try {
            Settings loaded = GSON.fromJson(Files.readString(FILE), Settings.class);
            if (loaded != null) CONFIG = loaded;
            CONFIG.normalize();
        } catch (Exception e) {
            System.err.println("[ClutchMaster] Could not read config; using defaults: " + e.getMessage());
            CONFIG = new Settings();
        }
    }

    public static void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(CONFIG));
        } catch (IOException e) {
            System.err.println("[ClutchMaster] Could not save config: " + e.getMessage());
        }
    }

    public static final class Settings {
        public boolean enabled = false;
        public boolean waterBucket = true;
        public boolean slimeBlock = true;
        public boolean hayBale = true;
        public boolean cobweb = true;
        public boolean powderSnowBucket = true;
        public boolean boat = true;
        public boolean autoCameraAim = true;
        /** Degrees of camera rotation per client tick; higher is faster. */
        public float cameraRotationSpeed = 18.0f;
        /** Minimum downward velocity magnitude needed to arm the clutch. */
        public float fallDetectionSensitivity = 0.45f;
        /** Extra safety multiplier applied to the predicted trigger distance. */
        public float triggerDistanceMultiplier = 1.0f;
        /** Ordered from highest to lowest priority. */
        public List<String> clutchPriority = new ArrayList<>(List.of(
                "WATER_BUCKET", "POWDER_SNOW_BUCKET", "SLIME_BLOCK",
                "HAY_BALE", "COBWEB", "BOAT"
        ));

        private void normalize() {
            cameraRotationSpeed = clamp(cameraRotationSpeed, 1.0f, 90.0f);
            fallDetectionSensitivity = clamp(fallDetectionSensitivity, 0.05f, 2.0f);
            triggerDistanceMultiplier = clamp(triggerDistanceMultiplier, 0.5f, 2.0f);
            if (clutchPriority == null || clutchPriority.isEmpty()) {
                clutchPriority = new Settings().clutchPriority;
            }
        }

        private static float clamp(float v, float min, float max) {
            return Math.max(min, Math.min(max, v));
        }
    }
}
