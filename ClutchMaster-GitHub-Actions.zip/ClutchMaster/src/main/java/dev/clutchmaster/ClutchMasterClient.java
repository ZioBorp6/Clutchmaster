package dev.clutchmaster;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class ClutchMasterClient implements ClientModInitializer {
    public static final String MOD_ID = "clutchmaster";
    private static KeyBinding toggleKey;

    @Override
    public void onInitializeClient() {
        ClutchConfig.load();
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.clutchmaster.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_G,
                "category.clutchmaster"
        ));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                ClutchConfig.CONFIG.enabled = !ClutchConfig.CONFIG.enabled;
                ClutchConfig.save();
                ClutchController.onToggled(client, ClutchConfig.CONFIG.enabled);
            }
            ClutchController.tick(client);
        });
    }
}
