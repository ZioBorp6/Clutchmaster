package dev.clutchmaster;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.List;

public final class ClutchController {
    private enum Phase { IDLE, ARMED, RESTORING }
    private enum ClutchType {
        WATER_BUCKET(Items.WATER_BUCKET, "waterBucket"),
        POWDER_SNOW_BUCKET(Items.POWDER_SNOW_BUCKET, "powderSnowBucket"),
        SLIME_BLOCK(Items.SLIME_BLOCK, "slimeBlock"),
        HAY_BALE(Items.HAY_BLOCK, "hayBale"),
        COBWEB(Items.COBWEB, "cobweb"),
        BOAT(Items.OAK_BOAT, "boat");

        final Item item;
        final String configField;
        ClutchType(Item item, String configField) {
            this.item = item;
            this.configField = configField;
        }
    }

    private static Phase phase = Phase.IDLE;
    private static float oldYaw, oldPitch;
    private static int oldSlot = -1;
    private static int restoreTicks;
    private static ClutchType selectedType;
    private static BlockHitResult target;
    private static long lastAttemptTick;
    private static long tickCounter;

    private ClutchController() {}

    public static void onToggled(MinecraftClient client, boolean enabled) {
        if (!enabled) reset(client, true);
    }

    public static void tick(MinecraftClient client) {
        tickCounter++;
        if (client.player == null || client.world == null || client.interactionManager == null) {
            reset(client, false);
            return;
        }

        if (!ClutchConfig.CONFIG.enabled) {
            if (phase != Phase.IDLE) reset(client, true);
            return;
        }

        switch (phase) {
            case IDLE -> tryArm(client);
            case ARMED -> handleArmed(client);
            case RESTORING -> handleRestore(client);
        }
    }

    private static void tryArm(MinecraftClient client) {
        var player = client.player;
        if (player.isOnGround() || player.isFallFlying() || player.isTouchingWater()
                || player.getAbilities().flying || player.isClimbing() || player.isSpectator()) return;
        if (player.getVelocity().y >= -ClutchConfig.CONFIG.fallDetectionSensitivity) return;
        if (tickCounter - lastAttemptTick < 8) return;

        BlockHitResult ground = findGround(client);
        if (ground == null) return;

        double distance = Math.max(0.0, player.getY() - ground.getPos().y);
        double speed = Math.abs(player.getVelocity().y);
        double trigger = MathHelper.clamp(1.5 + speed * 2.2, 2.2, 5.0)
                * ClutchConfig.CONFIG.triggerDistanceMultiplier;
        if (distance > trigger) return;

        ClutchType choice = findBestAvailable(player.getInventory());
        if (choice == null) return;

        oldYaw = player.getYaw();
        oldPitch = player.getPitch();
        oldSlot = player.getInventory().selectedSlot;
        selectedType = choice;
        target = ground;
        phase = Phase.ARMED;
    }

    private static void handleArmed(MinecraftClient client) {
        var player = client.player;
        if (player == null || selectedType == null || target == null) {
            reset(client, true);
            return;
        }

        BlockHitResult currentGround = findGround(client);
        if (currentGround == null || player.isOnGround() || player.getVelocity().y >= 0.0) {
            beginRestore();
            return;
        }
        target = currentGround;

        if (ClutchConfig.CONFIG.autoCameraAim) {
            aimAt(player.getPos().add(0, -1, 0));
        }

        double distance = Math.max(0.0, player.getY() - target.getPos().y);
        double speed = Math.abs(player.getVelocity().y);
        double executeAt = MathHelper.clamp(1.15 + speed * 1.25, 1.5, 2.8);

        if (distance <= executeAt) {
            attempt(client);
        }
        // If the player is already too low, do not spam interactions.
        if (distance < 0.65) beginRestore();
    }

    private static void attempt(MinecraftClient client) {
        var player = client.player;
        PlayerInventory inventory = player.getInventory();
        int slot = findSlot(inventory, selectedType.item);
        if (slot < 0) {
            beginRestore();
            return;
        }

        inventory.selectedSlot = slot;
        BlockHitResult hit = findGround(client);
        if (hit == null) {
            beginRestore();
            return;
        }

        // Use the ordinary client interaction path. The server remains authoritative.
        client.interactionManager.interactBlock(player, Hand.MAIN_HAND, hit);
        lastAttemptTick = tickCounter;
        beginRestore();
    }

    private static void beginRestore() {
        phase = Phase.RESTORING;
        restoreTicks = 0;
    }

    private static void handleRestore(MinecraftClient client) {
        if (client.player == null) {
            phase = Phase.IDLE;
            return;
        }
        restoreTicks++;
        var player = client.player;
        if (ClutchConfig.CONFIG.autoCameraAim && restoreTicks <= 5) {
            player.setYaw(approachAngle(player.getYaw(), oldYaw, ClutchConfig.CONFIG.cameraRotationSpeed));
            player.setPitch(approach(player.getPitch(), oldPitch, ClutchConfig.CONFIG.cameraRotationSpeed));
        } else {
            player.setYaw(oldYaw);
            player.setPitch(oldPitch);
        }
        if (restoreTicks >= 5) {
            if (oldSlot >= 0 && oldSlot < 9) player.getInventory().selectedSlot = oldSlot;
            phase = Phase.IDLE;
            selectedType = null;
            target = null;
            oldSlot = -1;
        }
    }

    private static void aimAt(Vec3d destination) {
        var player = MinecraftClient.getInstance().player;
        Vec3d eyes = player.getCameraPosVec(1.0f);
        Vec3d delta = destination.subtract(eyes);
        double horizontal = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
        float desiredYaw = (float) (MathHelper.atan2(delta.z, delta.x) * 57.2957763671875) - 90.0f;
        float desiredPitch = (float) (-(MathHelper.atan2(delta.y, horizontal) * 57.2957763671875));
        float speed = ClutchConfig.CONFIG.cameraRotationSpeed;
        player.setYaw(approachAngle(player.getYaw(), desiredYaw, speed));
        player.setPitch(approach(player.getPitch(), desiredPitch, speed));
    }

    private static float approachAngle(float current, float target, float maxStep) {
        float difference = MathHelper.wrapDegrees(target - current);
        return current + MathHelper.clamp(difference, -maxStep, maxStep);
    }

    private static float approach(float current, float target, float maxStep) {
        return current + MathHelper.clamp(target - current, -maxStep, maxStep);
    }

    private static BlockHitResult findGround(MinecraftClient client) {
        var player = client.player;
        Vec3d start = player.getPos().add(0, 0.15, 0);
        Vec3d end = start.add(0, -64.0, 0);
        HitResult result = client.world.raycast(new RaycastContext(
                start, end, RaycastContext.ShapeType.OUTLINE,
                RaycastContext.FluidHandling.NONE, player
        ));
        if (result.getType() != HitResult.Type.BLOCK) return null;
        return (BlockHitResult) result;
    }

    private static ClutchType findBestAvailable(PlayerInventory inventory) {
        List<String> priority = ClutchConfig.CONFIG.clutchPriority;
        for (String name : priority) {
            try {
                ClutchType type = ClutchType.valueOf(name);
                if (isEnabled(type) && findSlot(inventory, type.item) >= 0) return type;
            } catch (IllegalArgumentException ignored) {
                // Unknown config entry: ignore it rather than failing the client.
            }
        }
        // Include any enabled type omitted from a hand-edited priority list.
        for (ClutchType type : ClutchType.values()) {
            if (isEnabled(type) && findSlot(inventory, type.item) >= 0) return type;
        }
        return null;
    }

    private static boolean isEnabled(ClutchType type) {
        var c = ClutchConfig.CONFIG;
        return switch (type) {
            case WATER_BUCKET -> c.waterBucket;
            case POWDER_SNOW_BUCKET -> c.powderSnowBucket;
            case SLIME_BLOCK -> c.slimeBlock;
            case HAY_BALE -> c.hayBale;
            case COBWEB -> c.cobweb;
            case BOAT -> c.boat;
        };
    }

    private static int findSlot(PlayerInventory inventory, Item item) {
        for (int i = 0; i < 9; i++) {
            if (inventory.getStack(i).isOf(item)) return i;
        }
        return -1;
    }

    private static void reset(MinecraftClient client, boolean restore) {
        if (restore && client.player != null) {
            if (oldSlot >= 0 && oldSlot < 9) client.player.getInventory().selectedSlot = oldSlot;
            if (phase != Phase.IDLE) {
                client.player.setYaw(oldYaw);
                client.player.setPitch(oldPitch);
            }
        }
        phase = Phase.IDLE;
        selectedType = null;
        target = null;
        oldSlot = -1;
    }
}
