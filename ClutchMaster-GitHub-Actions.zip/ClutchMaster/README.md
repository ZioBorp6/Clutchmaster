# ClutchMaster

Client-side Fabric QoL mod for Minecraft Java Edition **1.20.1**.

## Features

- Fall detection using downward player velocity.
- Downward block raycast to estimate distance to the landing surface.
- Optional camera aiming with configurable rotation speed.
- Hotbar search for Water Bucket, Powder Snow Bucket, Slime Block, Hay Bale, Cobweb, and Oak Boat.
- Configurable clutch toggles and priority order.
- Restores the previous hotbar slot and camera direction after an attempt.
- Uses the normal Fabric/Minecraft client interaction manager. No custom packets, server bypasses, or server-side mod.

## Requirements

- Minecraft Java Edition 1.20.1
- Java 17
- Fabric Loader 0.15.x or newer for 1.20.1
- Fabric API 0.92.2+1.20.1

## Build

From this directory, run:

```bash
gradle build
```

The release mod JAR is created at:

```text
build/libs/clutchmaster-1.0.0.jar
```

This project uses Fabric Loom 1.6.12, Yarn `1.20.1+build.10`, and Java 17 bytecode.

## Install

1. Install Fabric Loader for Minecraft 1.20.1.
2. Install the matching Fabric API into the `.minecraft/mods` folder.
3. Copy `clutchmaster-1.0.0.jar` into `.minecraft/mods`.
4. Launch the Fabric 1.20.1 profile.

## Controls

- Press **G** to enable or disable Auto MLG.
- The key can be rebound in **Options → Controls → Key Binds → ClutchMaster**.

## Configuration

After the first launch, edit:

```text
.minecraft/config/clutchmaster.json
```

The file is generated automatically. It contains:

- `enabled`
- `waterBucket`
- `slimeBlock`
- `hayBale`
- `cobweb`
- `powderSnowBucket`
- `boat`
- `autoCameraAim`
- `cameraRotationSpeed` (degrees per client tick; 1–90)
- `fallDetectionSensitivity` (minimum downward velocity magnitude)
- `triggerDistanceMultiplier`
- `clutchPriority` (highest priority first)

Restart the game after editing the JSON file.

## Important behavior and limitations

- This is an assistance feature, not a guarantee of a successful clutch. The server controls whether a placement is accepted.
- The mod makes one normal interaction attempt per detected fall. It does not repeatedly send packets.
- The current implementation aims at and interacts with the block surface directly below the player.
- Boat clutch behavior is situational and depends on whether the target surface and server rules permit placing/using a boat.
- Water and Powder Snow buckets can be restricted by dimension, region, game mode, or server rules.
- The camera and selected hotbar slot are restored after the attempt sequence; abrupt disconnects or world changes may interrupt restoration.

## License

MIT


## Build automatically with GitHub Actions

1. Upload the complete project to a GitHub repository, keeping the `.github/workflows/build.yml` file.
2. Open the repository's **Actions** tab.
3. Select **Build ClutchMaster** and choose **Run workflow**, or push a commit to `main`/`master`.
4. Open the completed workflow run.
5. Under **Artifacts**, download `ClutchMaster-build`.
6. Extract it and use the regular `clutchmaster-1.0.0.jar` file (not a `-sources.jar` file) in your Fabric `mods` folder.

A successful workflow run confirms that Gradle compilation completed. It does not replace in-game testing.
